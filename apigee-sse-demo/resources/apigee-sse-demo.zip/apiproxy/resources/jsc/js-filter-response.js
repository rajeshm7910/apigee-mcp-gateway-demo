var eventstring = context.getVariable("response.event.current.content");
eventstring = eventstring.replace("data:", "");
var eventJson = JSON.parse(eventstring);

var key = "modelVersion";
delete eventJson[key];

context.setVariable("response.event.current.content", JSON.stringify(eventJson));
